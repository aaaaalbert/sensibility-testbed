#!/bin/sh

cd "`echo $0 | sed 's/install.sh/seattle_repy/'`"
./install.sh $*

