#!/bin/sh

cd "`echo $0 | sed 's/stop_seattle.sh/seattle_repy/'`"
./stop_seattle.sh