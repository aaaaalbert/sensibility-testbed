#!/bin/sh

cd "`echo $0 | sed 's/start_seattle.sh/seattle_repy/'`"
./start_seattle.sh